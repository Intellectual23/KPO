class ConsoleApp {
    private val users: MutableList<User> = mutableListOf()
    private var currentUser: User? = null

    // Запуск приложения кинотеатра с удобным и интуитивно понятным управлением.
    fun run() {
        val cinema = Cinema()
        println("- Welcome to the cinema!")

        while (true) {
            if (currentUser == null) {
                print(
                    "Choose an option:\n" +
                            "1 - Register\n" +
                            "2 - Login\n" +
                            "3 - Exit\n"
                )

                when (readln()) {
                    "1" -> registerUser()
                    "2" -> login()
                    "3" -> {
                        println("- Goodbye!")
                        break
                    }

                    else -> println("- Wrong option!")
                }
            } else {
                print(
                    "Choose an option:\n" +
                            "1 - Book a ticket\n" +
                            "2 - Return a ticket\n" +
                            "3 - Show Seats\n" +
                            "4 - Edit film or session\n" +
                            "5 - Mark the presence\n" +
                            "6 - Show Tickets\n" +
                            "7 - Save progress(write cinema data to files)\n" +
                            "8 - Load progress(read cinema data from files)\n" +
                            "9 - Logout\n"
                )

                when (readln()) {
                    "1" -> cinema.bookTicket()
                    "2" -> cinema.returnTicket()
                    "3" -> cinema.showSeats()
                    "4" -> cinema.editMode()
                    "5" -> cinema.markPresence()
                    "6" -> cinema.showTickets()
                    "7" -> cinema.saveData()
                    "8" -> cinema.loadData()
                    "9" -> {
                        currentUser = null
                        println("- Logout successful!")
                    }

                    else -> println("- Wrong option!")
                }
            }
        }
    }

    // Класс пользователя с логином и паролем, методом сверки пароля.
    inner class User(val username: String, private val password: String) {
        fun matchesPassword(inputPassword: String): Boolean {
            return encryptPassword(inputPassword) == password
        }
    }

    // Регистрация пользователя.
    private fun registerUser() {
        print("Enter your username: ")
        val username = readln()
        print("Enter your password: ")
        val password = readln()

        val encryptedPassword = encryptPassword(password)
        val newUser = User(username, encryptedPassword)
        users.add(newUser)

        println("- Registration successful!")
    }

    // Авторизация пользователя.
    private fun login() {
        print("Enter your username: ")
        val username = readln()
        print("Enter your password: ")
        val password = readln()

        val user = users.find { it.username == username }

        if (user != null && user.matchesPassword(password)) {
            currentUser = user
            println("- Login successful!")
        } else {
            println("- Invalid username or password!")
        }
    }

    // Простое шифрование пароля, сдвиг ascii кода на 3 символа вперед.
    private fun encryptPassword(password: String): String {
        val encodedPassword = StringBuilder()
        for (char in password) {
            val asciiValue = char.code
            val shiftedAsciiValue = asciiValue + 3
            val shiftedChar = shiftedAsciiValue.toChar()
            encodedPassword.append(shiftedChar)
        }
        return encodedPassword.toString()
    }
}