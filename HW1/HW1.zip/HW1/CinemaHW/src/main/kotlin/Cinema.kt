import kotlinx.datetime.*
import java.lang.Exception
import kotlin.math.abs

// Размер стороны кинотеатра, нужен для моделирования зала NxN - очень удобно!
val CINEMA_SIZE = 5;

// Класс кинотеатра, три поля-списка из данных, которые сохраняются в три файла, и поле-сериализатор.
class Cinema {
    var sessions: MutableList<Session> = mutableListOf()
    var films: MutableList<Film> = mutableListOf()
    var tickets: MutableList<Ticket> = mutableListOf()
    val serializer = Serializer();

    // Для удобства и тестирования создаю 4 фильма при инициализации и 3 сессии с привязкой к текущему времени.
    init {
        films.add(Film("Interstellar", "Interstellar description", 180))
        films.add(Film("Pulp Fiction", "Pulp Fiction description", 120))
        films.add(Film("Snatch", "Snatch description", 120))
        films.add(Film("Drive", "Gosling didn’t die at the end of the drive", 100))
        val currentTime = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault())
        sessions.add(Session(films[0], currentTime))
        val secondTime = currentTime.toJavaLocalDateTime().plusHours(1).toKotlinLocalDateTime();
        sessions.add(Session(films[1], secondTime))
        val thirdTime = currentTime.toJavaLocalDateTime().plusHours(2).toKotlinLocalDateTime();
        sessions.add(Session(films[2], thirdTime))
    }

    // Возможность фиксации продажи посетителям кинотеатра билетов на сеанс с выбором мест.
    fun bookTicket() {
        val session = chooseSession();
        print("Enter Customer Name: ")
        val name = readln()
        session.showHall()
        print("Choose a seat: ")
        val seatNum = readln().toInt();
        try {
            if (session.hall[seatNum - 1].isFree) {
                session.hall[seatNum - 1].isFree = false;
                tickets.add(Ticket(name, session, seatNum))
                println("- Ticket was successfully Booked.")

            } else {
                println("! This seat have been already taken! ")
            }
        } catch (e: Exception) {
            print("! Incorrect seat! Try again.")
        }
    }

    // Реализация возможности возврата проданных билетов посетителям до начала сеанса.
    fun returnTicket() {
        if (sessions.size == 0) {
            println("! We are out of sessions!")
            return;
        }
        val session = chooseSession();
        print("Enter Customer name:")
        val name = readln();
        print("Enter seat num: ")
        val seat = readln().toInt()
        for (ticket in tickets) {
            if (ticket.session.date == session.date && ticket.customer == name && ticket.seat == seat) {
                val currentTime = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault())
                if (currentTime >= ticket.session.date) {
                    println("! This session is already started or ended!")
                    return;
                }
                session.hall[ticket.seat - 1].isFree = true;
                tickets.remove(ticket);
                println("- Ticket has been returned!")
                return;
            }
        }
        print("! Error! Ticket wasn't found.")

    }

    // Возможность отображения свободных и проданных мест для выбранного сеанса.
    fun showSeats() {
        if (sessions.size == 0) {
            println("! We are out of sessions!")
            return;
        }
        chooseSession().showHall();
    }

    // Возможность редактирования данных о фильмах, находящихся в прокате кинотеатра, и расписания сеансов их показа.
    fun editMode() {
        println("Welcome to Edit Mode!")
        while (true) {
            print(
                "Choose an option:\n" +
                        "1 - Add new film\n" +
                        "2 - Add new session\n" +
                        "3 - Delete film\n" +
                        "4 - Delete session\n" +
                        "5 - Edit film\n" +
                        "6 - Edit session\n" +
                        "7 - Exit\n"
            );
            when (readln()) {
                "1" -> addNewFilm();
                "2" -> addNewSession();
                "3" -> deleteFilm();
                "4" -> closeSession();
                "5" -> editFilm();
                "6" -> editSession();
                "7" -> break;
                else -> print("Wrong option!")
            }
        }
    }

    // Возможность отметки занятых мест в зале посетителями конкретного сеанса.
    fun markPresence() {
        if (sessions.size == 0) {
            println("! We are out of sessions!")
            return;
        }
        val session = chooseSession();
        if (!checkDate(session.date)) {
            println("! It's too late or too early!")
            return;
        }
        print("Enter seat: ")
        try {
            session.hall[readln().toInt() - 1].wasVisited = true;
            println("- Presence was marked!")
        } catch (e: Exception) {
            println("! Wrong seat, try again!")
        }

    }

    // Показывает список всех билетов, для удобства и проверки.
    fun showTickets() {
        for (ticket in tickets) {
            println(ticket)
        }
    }

    // Сохраняет данные о списках билетов, фильмов и сеансов в соответсвующие файлы.
    fun saveData() {
        serializer.serializeFilms(films);
        serializer.serializeTickets(tickets)
        serializer.serializeSessions(sessions);
    }

    // Загружает данные о билетах, фильмах, сеансах из соответсвующих файлов
    fun loadData() {
        films = serializer.deserializeFilms();
        tickets = serializer.deserializeTickets()
        sessions = serializer.deserializeSessions();
    }

    // Добавляет новый фильм в список фильмов.
    private fun addNewFilm() {
        print("Enter film name: ")
        val name = readln()
        print("Enter description: ")
        val description = readln();
        print("Enter duration in minutes:")
        try {

            val duration = readln().toInt();
            films.add(Film(name, description, duration));
            println("- Film ${name} was added.")
        } catch (e: Exception) {
            print("! Incorrect input!")
        }
    }

    // Добавляет новый сеанс в список сеансов.
    private fun addNewSession() {
        if (films.size == 0) {
            println("! We are out of films!")
            return;
        }
        val film = chooseFilm()
        val date = parseDate();
        sessions.add(Session(film, date))
        println("- Session was successfully added!")
    }

    // Показывает все фильмы из списка фильмов.
    private fun showFilms() {
        for (i in (0..films.size - 1)) {
            print("${i + 1}. " + films[i] + "\n")
        }
    }

    // Показывает все сенсы из списка сеансов.
    private fun showSessions() {
        println("Sessions schedule:")
        for (i in (0..sessions.size - 1)) {
            print("${i + 1}. " + sessions[i] + "\n")
        }
    }

    // Редактирует данные выбранного фильма.
    private fun editFilm() {
        if (films.size == 0) {
            println("! We are out of films!")
            return;
        }
        val film = chooseFilm()
        while (true) {
            print(
                "Choose an option:\n" +
                        "1 - Edit name\n" +
                        "2 - Edit description\n" +
                        "3 - Edit duration\n" +
                        "4 - exit\n"
            )
            when (readln()) {
                "1" -> film.editName();
                "2" -> film.editDescription();
                "3" -> film.editDuration();
                "4" -> break;
            }
        }
    }

    // Редактирует данные выбранного сеанса.
    private fun editSession() {
        if (sessions.size == 0) {
            println("! We are out of sessions!")
            return;
        }
        val session = chooseSession();
        while (true) {
            print(
                "Choose an option:\n" +
                        "1 - Change film\n" +
                        "2 - Change date\n" +
                        "3 - exit\n"
            )
            when (readln()) {
                "1" -> {
                    session.film = chooseFilm();
                    println("- Film was changed!")
                }

                "2" -> {
                    session.date = parseDate();
                    println("- Date was  changed!")
                }

                "3" -> break;
                else -> println("! Wrong option!")
            }
        }
    }

    // Удаляет выбранный фильм.
    private fun deleteFilm() {
        if (films.size == 0) {
            println("! We are out of films!")
            return;
        }
        films.remove(chooseFilm());
        println("- film was successfully deleted")
    }

    // Удаляет/закрывает выбранный сеанс.
    private fun closeSession() {
        if (sessions.size == 0) {
            println("! We are out of sessions!")
            return;
        }
        sessions.remove(chooseSession());
        println("- session was successfully deleted")
    }

    // Для избежания повторения кода выбора фильма.
    private fun chooseFilm(): Film {
        showFilms();
        while (true) {

            print("Choose film: ");
            try {
                return films[readln().toInt() - 1];
            } catch (e: Exception) {
                print("! Incorrect film! Try again\n");
            }
        }
    }

    // Для избежания повторения кода выбора сеанса.
    private fun chooseSession(): Session {
        showSessions();
        while (true) {

            print("Choose session: ");
            try {
                return sessions[readln().toInt() - 1];
            } catch (e: Exception) {
                print("! Incorrect session! Try again\n");
            }
        }
    }

    // Парсинг даты с консоли.
    private fun parseDate(): LocalDateTime {
        while (true) {
            try {
                print("Enter Year of date: ")
                val year = readln().toInt();
                print("Enter Month of date: ")
                val month = readln().toInt();
                print("Enter Day of date:")
                val day = readln().toInt();
                print("Enter Hours of date: ")
                val hours = readln().toInt();
                print("Enter Minutes of date: ")
                val minutes = readln().toInt();
                return LocalDateTime(year, month, day, hours, minutes);
            } catch (e: Exception) {
                println("! Incorrect date! Try again!")
            }
        }
    }

    // Проверяет, что переданнная дата отличается от текущей не более чем на 20 минут, используется в отметке присутсвия.
    private fun checkDate(date: LocalDateTime): Boolean {
        val currentDate = Clock.System.now().toLocalDateTime(TimeZone.currentSystemDefault())
        return if (currentDate.year != date.year || currentDate.month != date.month || currentDate.dayOfMonth != date.dayOfMonth) {
            false;
        } else {
            abs(currentDate.minute + currentDate.hour * 60 - date.minute - date.hour * 60) <= 20;
        }
    }
}