import kotlinx.serialization.Serializable

// Класс билета, сериализуемый.
@Serializable
class Ticket(public var customer: String, public var session: Session, public val seat: Int) {
    override fun toString(): String {
        return "Film: ${session.film.name}, date: ${session.date}, Customer: ${customer}, seat#${seat}"
    }
}