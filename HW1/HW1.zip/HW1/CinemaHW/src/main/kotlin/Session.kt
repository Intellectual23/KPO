import kotlinx.serialization.Serializable
import kotlinx.datetime.LocalDateTime

// Класс сеанса, сериализуем. Внутри встроен класс сиденья для удобства, зал это список из сидений.
@Serializable
class Session(public var film: Film, public var date: LocalDateTime) {
    var hall: MutableList<Seat> = mutableListOf()

    init {
        for (i in 0 until CINEMA_SIZE) {
            for (j in 0 until CINEMA_SIZE) {
                hall.add(Seat(i, j))
            }
        }
    }

    // Показ свободных и занятых мест.
    fun showHall() {
        print("Free Seats:\n")
        for (i in 0 until CINEMA_SIZE) {
            for (j in 0 until CINEMA_SIZE) {
                if (hall[i * CINEMA_SIZE + j].isFree) {
                    print(hall[i * CINEMA_SIZE + j].getNumber() + " ")
                } else {
                    print("    ")
                }
            }
            print("\n")
        }
    }

    override fun toString(): String {
        return "${film.name} - $date"
    }
}

// Внутренний класс сиденья с методом подсчета номера по ряду и месту в ряде.
@Serializable
class Seat(public val row: Int, public val place: Int) {
    var isFree: Boolean = true
    var wasVisited: Boolean = false

    // Поддерживает до 999 мест.
    fun getNumber(): String {
        val num = row * CINEMA_SIZE + place + 1
        return when {
            num < 10 -> "00$num"
            num < 100 -> "0$num"
            else -> "$num"
        }
    }
}