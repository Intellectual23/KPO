import kotlinx.serialization.Serializable

// Класс фильма, сериализуемый, используется методы редактирования полей.
@Serializable
class Film(public var name: String, public var description: String, public var duration: Int) {
    override fun toString(): String {
        return "${name}\n Description: ${description}\n Duration: ${duration} minutes"
    }

    fun editName() {
        print("Enter new name: ")
        name = readLine().toString()
    }

    fun editDescription() {
        print("Enter new description: ")
        description = readLine().toString()
    }

    fun editDuration() {
        print("Enter new duration in minutes: ")
        duration = readLine().toString().toInt()
    }
}