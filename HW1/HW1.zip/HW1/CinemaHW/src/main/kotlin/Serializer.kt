import kotlinx.serialization.json.Json
import kotlinx.serialization.encodeToString
import java.io.File

// Для сериализации использую отдельный класс, пути до файлов заданы в полях.
// Сюда так же можно добавить методы для сериализаци пользователей.
class Serializer() {
    private val sessionsFile = File("files/sessions.json")
    private val ticketsFile = File("files/tickets.json")
    private val filmsFile = File("files/films.json")

    fun serializeSessions(sessions: MutableList<Session>) {
        val sessionsJson = Json.encodeToString(sessions);
        sessionsFile.writeText(sessionsJson)
        println("- Sessions were saved in \"sessions.json\" ")
    }

    fun serializeTickets(tickets: MutableList<Ticket>) {
        val ticketsJson = Json.encodeToString(tickets);
        ticketsFile.writeText(ticketsJson)
        println("- Tickets were saved in \"tickets.json\" ")
    }

    fun serializeFilms(films: MutableList<Film>) {
        val filmsJson = Json.encodeToString(films);
        filmsFile.writeText(filmsJson)
        println("- Films were saved in \"tickets.json\" ")
    }

    fun deserializeSessions(): MutableList<Session> {
        val deserializedSessionsJson = sessionsFile.readText()
        val deserializedSessions = Json.decodeFromString<MutableList<Session>>(deserializedSessionsJson)
        println("- Sessions were loaded from \"sessions.json\" ")
        return deserializedSessions;
    }

    fun deserializeTickets(): MutableList<Ticket> {
        val deserializedTicketsJson = ticketsFile.readText()
        val deserializedTickets = Json.decodeFromString<MutableList<Ticket>>(deserializedTicketsJson)
        println("- Tickets were loaded from \"tickets.json\" ")
        return deserializedTickets;
    }

    fun deserializeFilms(): MutableList<Film> {
        val deserializedFilmsJson = filmsFile.readText()
        val deserializedFilms = Json.decodeFromString<MutableList<Film>>(deserializedFilmsJson)
        println("- Films were loaded from \"films.json\" ")
        return deserializedFilms;
    }
}