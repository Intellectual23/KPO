// Запускаем!
fun main(args: Array<String>) {
    val app = ConsoleApp()
    app.run()
}